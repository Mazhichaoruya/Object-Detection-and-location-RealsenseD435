// Copyright (C) 2007  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_TUPLe_TOP_
#define DLIB_TUPLe_TOP_ 

#include "tuple/tuple.h"

#endif // DLIB_TUPLe_TOPh_


